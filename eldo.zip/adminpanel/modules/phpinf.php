<?php
include "../../cfg.php";
include "../../ini.php";
defined('ACCESS') or die();
if($status == 1) {
	phpinfo();
}
?>