<?php
	 print $body;
?>